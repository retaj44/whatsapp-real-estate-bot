# -*- coding: utf-8 -*-
import os
import html
import uuid
from datetime import datetime

from flask import Flask, render_template, request, redirect, url_for, session, flash, g
from flask_sqlalchemy import SQLAlchemy
from markupsafe import Markup
from werkzeug.utils import secure_filename

from translations import get_translator

app = Flask(__name__)
app.config['SECRET_KEY'] = 'change-this-secret-key-later'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///maskan.db'
app.config['UPLOAD_FOLDER'] = os.path.join(app.root_path, 'static', 'uploads')
app.config['MAX_CONTENT_LENGTH'] = 8 * 1024 * 1024  # 8MB uploads
db = SQLAlchemy(app)

os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'webp', 'gif'}

# --- Simple hardcoded admin password (change this for real use) ---
ADMIN_PASSWORD = 'admin123'

# --- Approximate coordinates for major Saudi cities (fallback when a
#     property has no exact lat/lng saved) ---
SAUDI_CITY_COORDS = {
    'riyadh': (24.7136, 46.6753),
    'jeddah': (21.4858, 39.1925),
    'dammam': (26.4207, 50.0888),
    'mecca': (21.3891, 39.8579),
    'makkah': (21.3891, 39.8579),
    'medina': (24.5247, 39.5692),
    'madinah': (24.5247, 39.5692),
    'khobar': (26.2172, 50.1971),
    'al khobar': (26.2172, 50.1971),
    'taif': (21.2703, 40.4158),
    'tabuk': (28.3998, 36.5715),
    'buraidah': (26.3260, 43.9750),
    'khamis mushait': (18.3000, 42.7333),
    'abha': (18.2164, 42.5053),
    'najran': (17.4924, 44.1277),
    'jazan': (16.8892, 42.5611),
    'jizan': (16.8892, 42.5611),
    'yanbu': (24.0895, 38.0618),
    'al ahsa': (25.3833, 49.5867),
    'hail': (27.5114, 41.7208),
    'qatif': (26.5205, 50.0086),
}


def get_city_coords(location_name):
    """Best-effort lookup of lat/lng for a free-text Saudi city string."""
    if not location_name:
        return None
    key = location_name.strip().lower()
    if key in SAUDI_CITY_COORDS:
        return SAUDI_CITY_COORDS[key]
    for city, coords in SAUDI_CITY_COORDS.items():
        if city in key or key in city:
            return coords
    return None


def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


def save_uploaded_image(file_storage):
    """Saves an uploaded image with a unique name, returns its public URL or None."""
    if not file_storage or not file_storage.filename:
        return None
    if not allowed_file(file_storage.filename):
        return None
    ext = file_storage.filename.rsplit('.', 1)[1].lower()
    unique_name = f"{uuid.uuid4().hex}.{ext}"
    file_storage.save(os.path.join(app.config['UPLOAD_FOLDER'], unique_name))
    return url_for('static', filename=f'uploads/{unique_name}')


# ---------------- Models ----------------
class Property(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(150), nullable=False)
    description = db.Column(db.Text, nullable=False)
    price = db.Column(db.Integer, nullable=False)
    location = db.Column(db.String(100), nullable=False)
    property_type = db.Column(db.String(50), nullable=False)  # Apartment, Villa, Studio, Land
    status = db.Column(db.String(20), nullable=False, default='For Sale')  # For Sale / For Rent
    bedrooms = db.Column(db.Integer, default=0)
    bathrooms = db.Column(db.Integer, default=0)
    area = db.Column(db.Integer, nullable=False)  # sqm
    image_url = db.Column(db.String(300), default='https://images.unsplash.com/photo-1568605114967-8130f3a36994?w=800')
    latitude = db.Column(db.Float, nullable=True)
    longitude = db.Column(db.Float, nullable=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def coords(self):
        if self.latitude is not None and self.longitude is not None:
            return (self.latitude, self.longitude)
        return get_city_coords(self.location)


class BlogPost(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    slug = db.Column(db.String(220), unique=True, nullable=False)
    excerpt = db.Column(db.String(300), nullable=False)
    content = db.Column(db.Text, nullable=False)  # blank-line separated paragraphs; "## " -> heading
    cover_image = db.Column(db.String(300), default='https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=1200')
    author = db.Column(db.String(100), default='Asaheeb Team')
    reading_time = db.Column(db.Integer, default=5)
    tags = db.Column(db.String(200), default='')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def tag_list(self):
        return [t.strip() for t in self.tags.split(',') if t.strip()]


# ---------------- i18n ----------------
@app.before_request
def set_language():
    if 'lang' not in session:
        session['lang'] = 'ar'  # Arabic is the default language on first visit
    g.lang = session['lang']
    g.t = get_translator(g.lang)
    g.dir = 'rtl' if g.lang == 'ar' else 'ltr'


@app.context_processor
def inject_i18n():
    return dict(t=g.t, lang=g.lang, dir=g.dir)


@app.route('/set-language/<lang_code>')
def set_language_route(lang_code):
    if lang_code in ('ar', 'en'):
        session['lang'] = lang_code
    return redirect(request.referrer or url_for('home'))


# ---------------- Template filters ----------------
@app.template_filter('render_article')
def render_article(text):
    """Turns lightweight markup (blank-line paragraphs, '## '/'### ' headings)
    into safe HTML for the blog article template."""
    if not text:
        return Markup('')
    blocks = [b.strip() for b in text.strip().split('\n\n') if b.strip()]
    parts = []
    for b in blocks:
        if b.startswith('### '):
            parts.append(f'<h3>{html.escape(b[4:])}</h3>')
        elif b.startswith('## '):
            parts.append(f'<h2>{html.escape(b[3:])}</h2>')
        elif b.startswith('- '):
            items = ''.join(f'<li>{html.escape(line[2:].strip())}</li>' for line in b.split('\n') if line.strip())
            parts.append(f'<ul>{items}</ul>')
        else:
            parts.append(f'<p>{html.escape(b)}</p>')
    return Markup('\n'.join(parts))


# ---------------- Helper ----------------
def is_logged_in():
    return session.get('is_admin', False)


def build_property_markers(results):
    import random
    random.seed(42)
    markers = []
    for p in results:
        coords = p.coords()
        if coords:
            has_exact = p.latitude is not None and p.longitude is not None
            jitter_lat = coords[0] if has_exact else coords[0] + random.uniform(-0.03, 0.03)
            jitter_lng = coords[1] if has_exact else coords[1] + random.uniform(-0.03, 0.03)
            markers.append({
                'id': p.id,
                'title': p.title,
                'location': p.location,
                'price': p.price,
                'status': p.status,
                'lat': jitter_lat,
                'lng': jitter_lng,
                'url': url_for('property_detail', property_id=p.id)
            })
    return markers


# ---------------- Public routes ----------------
@app.route('/')
def home():
    featured = Property.query.order_by(Property.created_at.desc()).limit(6).all()
    posts = BlogPost.query.order_by(BlogPost.created_at.desc()).limit(3).all()

    city_counts = {}
    for loc, in db.session.query(Property.location).all():
        key = loc.strip()
        city_counts[key] = city_counts.get(key, 0) + 1

    map_locations = []
    for city, count in city_counts.items():
        coords = get_city_coords(city)
        if coords:
            map_locations.append({
                'name': city,
                'lat': coords[0],
                'lng': coords[1],
                'count': count
            })

    return render_template('index.html', featured=featured, map_locations=map_locations, posts=posts)


@app.route('/properties')
def properties():
    query = Property.query

    location = request.args.get('location', '').strip()
    property_type = request.args.get('property_type', '').strip()
    status = request.args.get('status', '').strip()
    min_price = request.args.get('min_price', type=int)
    max_price = request.args.get('max_price', type=int)
    bedrooms = request.args.get('bedrooms', type=int)

    if location:
        query = query.filter(Property.location.ilike(f'%{location}%'))
    if property_type:
        query = query.filter(Property.property_type == property_type)
    if status:
        query = query.filter(Property.status == status)
    if min_price is not None:
        query = query.filter(Property.price >= min_price)
    if max_price is not None:
        query = query.filter(Property.price <= max_price)
    if bedrooms is not None:
        query = query.filter(Property.bedrooms >= bedrooms)

    results = query.order_by(Property.created_at.desc()).all()

    all_locations = [r[0] for r in db.session.query(Property.location).distinct()]
    all_types = [r[0] for r in db.session.query(Property.property_type).distinct()]

    property_markers = build_property_markers(results)

    return render_template(
        'properties.html',
        properties=results,
        all_locations=all_locations,
        all_types=all_types,
        filters=request.args,
        property_markers=property_markers
    )


@app.route('/properties/<int:property_id>')
def property_detail(property_id):
    prop = Property.query.get_or_404(property_id)
    return render_template('detail.html', prop=prop)


@app.route('/catalog')
def catalog():
    return render_template('catalog.html', pdf_url=url_for('static', filename='catalog/Project.pdf'))


@app.route('/about')
def about():
    return render_template('about.html')


@app.route('/contact')
def contact():
    return render_template('contact.html')


# ---------------- Blog / Insights ----------------
@app.route('/blog')
def blog_list():
    posts = BlogPost.query.order_by(BlogPost.created_at.desc()).all()
    return render_template('blog_list.html', posts=posts)


@app.route('/blog/<slug>')
def blog_post(slug):
    post = BlogPost.query.filter_by(slug=slug).first_or_404()
    related = BlogPost.query.filter(BlogPost.id != post.id).order_by(BlogPost.created_at.desc()).limit(2).all()
    return render_template('blog_post.html', post=post, related=related)


# ---------------- Admin routes ----------------
@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        password = request.form.get('password', '')
        if password == ADMIN_PASSWORD:
            session['is_admin'] = True
            return redirect(url_for('admin_dashboard'))
        else:
            flash('Incorrect password.')
    return render_template('admin_login.html')


@app.route('/admin/logout')
def admin_logout():
    session.pop('is_admin', None)
    return redirect(url_for('home'))


@app.route('/admin')
def admin_dashboard():
    if not is_logged_in():
        return redirect(url_for('admin_login'))
    all_properties = Property.query.order_by(Property.created_at.desc()).all()
    all_posts = BlogPost.query.order_by(BlogPost.created_at.desc()).all()
    return render_template('admin_dashboard.html', properties=all_properties, posts=all_posts)


@app.route('/admin/add', methods=['GET', 'POST'])
def admin_add():
    if not is_logged_in():
        return redirect(url_for('admin_login'))

    if request.method == 'POST':
        uploaded_url = save_uploaded_image(request.files.get('image_file'))
        image_url = uploaded_url or request.form.get('image_url') or Property.image_url.default.arg

        lat = request.form.get('latitude', type=float)
        lng = request.form.get('longitude', type=float)

        new_property = Property(
            title=request.form['title'],
            description=request.form['description'],
            price=int(request.form['price']),
            location=request.form['location'],
            property_type=request.form['property_type'],
            status=request.form['status'],
            bedrooms=int(request.form.get('bedrooms') or 0),
            bathrooms=int(request.form.get('bathrooms') or 0),
            area=int(request.form['area']),
            image_url=image_url,
            latitude=lat,
            longitude=lng,
        )
        db.session.add(new_property)
        db.session.commit()
        flash('Property added successfully!')
        return redirect(url_for('admin_dashboard'))

    return render_template('admin_add.html')


@app.route('/admin/delete/<int:property_id>', methods=['POST'])
def admin_delete(property_id):
    if not is_logged_in():
        return redirect(url_for('admin_login'))
    prop = Property.query.get_or_404(property_id)
    db.session.delete(prop)
    db.session.commit()
    flash('Property deleted.')
    return redirect(url_for('admin_dashboard'))


def slugify(text):
    import re
    text = text.strip().lower()
    text = re.sub(r'[^a-z0-9\u0600-\u06FF\s-]', '', text)
    text = re.sub(r'[\s-]+', '-', text).strip('-')
    return text or uuid.uuid4().hex[:8]


@app.route('/admin/blog/add', methods=['GET', 'POST'])
def admin_blog_add():
    if not is_logged_in():
        return redirect(url_for('admin_login'))

    if request.method == 'POST':
        uploaded_url = save_uploaded_image(request.files.get('cover_file'))
        cover_image = uploaded_url or request.form.get('cover_image') or BlogPost.cover_image.default.arg

        title = request.form['title']
        base_slug = slugify(title)
        slug = base_slug
        i = 2
        while BlogPost.query.filter_by(slug=slug).first():
            slug = f"{base_slug}-{i}"
            i += 1

        new_post = BlogPost(
            title=title,
            slug=slug,
            excerpt=request.form['excerpt'],
            content=request.form['content'],
            cover_image=cover_image,
            author=request.form.get('author') or 'Asaheeb Team',
            reading_time=int(request.form.get('reading_time') or 5),
            tags=request.form.get('tags', ''),
        )
        db.session.add(new_post)
        db.session.commit()
        flash('Article published successfully!')
        return redirect(url_for('admin_dashboard'))

    return render_template('admin_blog_add.html')


@app.route('/admin/blog/delete/<int:post_id>', methods=['POST'])
def admin_blog_delete(post_id):
    if not is_logged_in():
        return redirect(url_for('admin_login'))
    post = BlogPost.query.get_or_404(post_id)
    db.session.delete(post)
    db.session.commit()
    flash('Article deleted.')
    return redirect(url_for('admin_dashboard'))


# ---------------- Seed sample data ----------------
def seed_data():
    if Property.query.count() == 0:
        samples = [
            Property(
                title='Modern 2-Bedroom Apartment in Al Nakheel',
                description='Bright open-plan apartment with a private balcony, covered parking, and 24/7 security. Minutes from schools and shopping centers.',
                price=650000, location='Riyadh', property_type='Apartment', status='For Sale',
                bedrooms=2, bathrooms=2, area=140,
                image_url='https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?w=800',
                latitude=24.7136, longitude=46.6753,
            ),
            Property(
                title='Luxury Villa with Private Garden',
                description='Spacious 5-bedroom villa with a private garden, swimming pool, and dedicated parking. Perfect for families.',
                price=2100000, location='Jeddah', property_type='Villa', status='For Sale',
                bedrooms=5, bathrooms=4, area=450,
                image_url='https://images.unsplash.com/photo-1613977257363-707ba9348227?w=800',
                latitude=21.4858, longitude=39.1925,
            ),
            Property(
                title='Cozy Furnished Studio',
                description='Fully furnished studio close to public transport and cafes. Ideal for singles or students.',
                price=2500, location='Dammam', property_type='Studio', status='For Rent',
                bedrooms=1, bathrooms=1, area=45,
                image_url='https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?w=800',
                latitude=26.4207, longitude=50.0888,
            ),
            Property(
                title='Family Apartment Near Downtown',
                description='3-bedroom apartment with a modern kitchen and two bathrooms, walking distance to the city center.',
                price=850000, location='Riyadh', property_type='Apartment', status='For Sale',
                bedrooms=3, bathrooms=2, area=180,
                image_url='https://images.unsplash.com/photo-1560448204-e02f11c3d0e2?w=800',
                latitude=24.7300, longitude=46.6900,
            ),
            Property(
                title='Seaside Villa with Pool',
                description='Elegant 4-bedroom villa near the Corniche with a private pool and landscaped garden.',
                price=1850000, location='Khobar', property_type='Villa', status='For Sale',
                bedrooms=4, bathrooms=4, area=380,
                image_url='https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=800',
                latitude=26.2172, longitude=50.1971,
            ),
            Property(
                title='Modern Apartment Near Haram',
                description='Well-located 2-bedroom apartment with easy access to the Haram, ideal for families and investors.',
                price=980000, location='Mecca', property_type='Apartment', status='For Sale',
                bedrooms=2, bathrooms=2, area=130,
                image_url='https://images.unsplash.com/photo-1512917774080-9991f1c4c750?w=800',
                latitude=21.3891, longitude=39.8579,
            ),
            Property(
                title='Spacious Land Plot',
                description='Prime residential land plot in a fast-growing neighborhood, ready for development.',
                price=1200000, location='Taif', property_type='Land', status='For Sale',
                bedrooms=0, bathrooms=0, area=600,
                image_url='https://images.unsplash.com/photo-1500382017468-9049fed747ef?w=800',
                latitude=21.2703, longitude=40.4158,
            ),
        ]
        db.session.bulk_save_objects(samples)
        db.session.commit()

    if BlogPost.query.count() == 0:
        posts = [
            BlogPost(
                title='خمس نصائح قبل شراء أول منزل لك في السعودية',
                slug='tips-before-buying-first-home-saudi',
                excerpt='شراء أول منزل خطوة مهمة تحتاج إلى تخطيط دقيق. هذه أهم النقاط التي يجب مراجعتها قبل التوقيع على العقد.',
                content=(
                    'شراء أول منزل هو أحد أهم القرارات المالية في حياة أي شخص أو أسرة. '
                    'قبل أن توقع على أي عقد، من المهم التوقف قليلًا ومراجعة النقاط الأساسية التي '
                    'تحدد إن كان هذا العقار مناسبًا لك على المدى الطويل.\n\n'
                    '## حدد ميزانيتك بدقة\n\n'
                    'لا تنظر فقط إلى سعر العقار، بل احسب أيضًا تكاليف النقل، الرسوم، والصيانة السنوية. '
                    'يُفضّل عادة ألا تتجاوز قيمة القسط الشهري نسبة معينة من دخلك الإجمالي حتى لا تشعر بالضغط المالي لاحقًا.\n\n'
                    '## اختر الموقع بعناية\n\n'
                    'الموقع يؤثر بشكل مباشر على قيمة العقار مستقبلًا وعلى راحتك اليومية. تحقق من قرب '
                    'المدارس، المستشفيات، الطرق الرئيسية، ومراكز التسوق قبل اتخاذ القرار النهائي.\n\n'
                    '## تحقق من الوثائق والصكوك\n\n'
                    'راجع صك الملكية، رخصة البناء، وحالة العقار القانونية جيدًا. يفضل الاستعانة بجهة موثوقة '
                    'للتأكد من خلو العقار من أي نزاعات أو رهون.\n\n'
                    '## عاين العقار أكثر من مرة\n\n'
                    'زيارة واحدة قد لا تكشف كل التفاصيل. حاول معاينة العقار في أوقات مختلفة من اليوم '
                    'للتأكد من الإضاءة، الضجيج، وحالة الأنظمة الكهربائية والصحية.\n\n'
                    '## استشر خبيرًا عقاريًا\n\n'
                    'فريق أصاحيب جاهز لمساعدتك في كل خطوة، من اختيار العقار المناسب حتى إتمام الإجراءات، '
                    'لضمان تجربة شراء سلسة وآمنة.'
                ),
                cover_image='https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=1200',
                author='فريق أصاحيب',
                reading_time=6,
                tags='شراء العقار, نصائح, السعودية',
            ),
            BlogPost(
                title='كيف تُقيّم قيمة العقار قبل الاستثمار فيه؟',
                slug='how-to-evaluate-property-value',
                excerpt='قبل استثمار أموالك في عقار، تعرف على أهم العوامل التي تحدد قيمته الحقيقية في السوق السعودي.',
                content=(
                    'تقييم العقار بشكل صحيح هو الفرق بين استثمار ناجح وقرار مالي مكلف. '
                    'فيما يلي أهم العوامل التي ينبغي مراعاتها عند تقييم أي عقار في السوق السعودي.\n\n'
                    '## الموقع والبنية التحتية\n\n'
                    'العقارات القريبة من الطرق الرئيسية، الخدمات، والمشاريع التطويرية الكبرى تحتفظ '
                    'بقيمتها وترتفع أسعارها بمعدل أسرع من غيرها.\n\n'
                    '## حالة العقار وعمره\n\n'
                    'العمر الإنشائي للمبنى وجودة التشطيبات يؤثران بشكل مباشر على السعر العادل، '
                    'وكذلك على تكاليف الصيانة المتوقعة في السنوات القادمة.\n\n'
                    '## مقارنة الأسعار في المنطقة\n\n'
                    'قارن سعر العقار بعقارات مشابهة في نفس الحي من حيث المساحة وعدد الغرف '
                    'للتأكد من أن السعر المطروح عادل وواقعي.\n\n'
                    '## الطلب المستقبلي على المنطقة\n\n'
                    'راقب المخططات العمرانية والمشاريع الحكومية القادمة، فهي غالبًا ما ترفع الطلب '
                    'والقيمة على العقارات في المناطق المحيطة بها.\n\n'
                    'فريق أصاحيب يقدم لك تقييمًا واقعيًا لأي عقار قبل اتخاذ قرار الاستثمار، '
                    'بالاستناد إلى بيانات السوق المحدثة.'
                ),
                cover_image='https://images.unsplash.com/photo-1600585154340-be6161a56a0c?w=1200',
                author='فريق أصاحيب',
                reading_time=5,
                tags='استثمار, تقييم عقاري',
            ),
        ]
        db.session.bulk_save_objects(posts)
        db.session.commit()


if __name__ == '__main__':
    with app.app_context():
        db.create_all()
        seed_data()
    app.run(debug=True, host='0.0.0.0', port=5000)
