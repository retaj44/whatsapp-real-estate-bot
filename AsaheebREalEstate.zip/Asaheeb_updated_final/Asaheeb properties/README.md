# Asaheeb Group — Updated Site

## What's new

1. **Arabic-first bilingual site.** The site opens in Arabic (right-to-left
   layout, Arabic fonts) by default. A globe/language pill in the nav bar
   switches to English and back — the choice is remembered for the visit.
   The navigation, buttons, headings, form labels, and footer are fully
   translated (see `translations.py`). Property listings and blog articles
   are stored exactly as the admin types them — enter them in Arabic,
   English, or both if you like; the toggle does not auto-translate content
   you write, only the site's built-in labels/menus.

2. **Animations**, closer to the reference sites you linked:
   - An animated scrolling ticker/marquee band under the hero (like agency
     sites use to list services/cities).
   - A slide-down, animated mobile menu with a hamburger icon.
   - Hover zoom on property/blog card images, "lift" hover on cards and
     buttons, and a soft page fade-in.
   - The scroll-reveal and animated stat counters from the original build
     are kept and now also apply to the new Blog section.

3. **Image uploads.** The "Add Property" and "Publish Article" admin forms
   now have a file picker. Upload a photo and it's saved to
   `static/uploads/` and served automatically — no more pasting only a URL
   (pasting a URL is still supported as a fallback).

4. **Pick the location on a map.** The "Add Property" form has a live map —
   click (or drag the pin) to set the exact latitude/longitude for a
   listing. That gets stored on the property and used on the homepage map,
   the properties map, and the property detail page, instead of only
   guessing the pin from the city name.

5. **Blog / Insights section**, styled like the article page you linked
   (bgcarabia.com): a full-width cover image, title + tags + "written by /
   date / reading time" meta row, clean article typography, a tags footer,
   share links, related articles, and a call-to-action block. Manage posts
   from the admin dashboard → "Publish New Article." Two sample Arabic
   real-estate articles are seeded so you can see the design immediately.

## Running it locally

```bash
cd maskan_flask
python3 -m venv venv
source venv/bin/activate        # venv\Scripts\activate on Windows
pip install -r requirements.txt
python app.py
```

Open http://localhost:5000. The database (`maskan.db`) and any uploaded
images (`static/uploads/`) are created automatically on first run, with the
original sample properties plus two sample blog posts pre-loaded.

- Admin login: `/admin/login`, password `admin123` (change `ADMIN_PASSWORD`
  in `app.py` before putting this online).
- Add a property: `/admin/add` (upload a photo, click the map to pin it).
- Publish an article: `/admin/blog/add`.

## Notes & things worth doing next

- The admin panel itself is left in English to keep the forms simple —
  only the public-facing pages are bilingual. Say the word if you'd like
  the admin UI translated too.
- Content translation (typing the same property/article in both languages)
  isn't automated — if you want a true dual-language content model (e.g.
  separate Arabic/English title & description fields per property), that's
  a reasonable next step but changes the admin forms, so I kept it out of
  this pass to avoid guessing at what you want there.
- `ADMIN_PASSWORD` and `SECRET_KEY` in `app.py` are still placeholders from
  the original project — replace both before deploying for real.
